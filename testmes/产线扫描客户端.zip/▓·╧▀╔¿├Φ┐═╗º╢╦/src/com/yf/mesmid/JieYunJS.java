package com.yf.mesmid;

import android.util.Log;

public class JieYunJS
{
	public void adcallback(String pid)
	{
		Log.d("wmcallback HTML:%s", pid);
	}
}
