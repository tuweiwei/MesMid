package com.yf.mesmid;

public interface SMTInfo {
	
	public int Getnumber();
	public String Getbarcode();
	public String Getrq();
	//public String Getzt();
	public String Getry();
	//public String Gettid();
	public void Setnumber(int number);
	public void Setbarcode(String barcode);
	public void Setrq(String rq);
	//public void Setzt(String zt);
	public void Setry(String ry);
	//public void Settid(String tid);
}
